# Importing libraries
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Icon, Color, Direction, Port, Side, Stop
from pybricks.tools import wait, StopWatch

# Initialize attachment motors
front_back_attachment_motor = Motor(Port.D)
left_right_attachment_motor = Motor(Port.C)

# Attachment functions  
def FB_Attachment(speed,angle,pause):
    front_back_attachment_motor.run_angle(speed,angle,then=Stop.HOLD,wait=pause)

def LR_Attachment(speed,angle,pause):
    left_right_attachment_motor.run_angle(speed,angle,then=Stop.HOLD,wait=pause)

# Initialize wheel motors
m_left = Motor(Port.A)
m_right = Motor(Port.B)

# Initialize PrimeHub
hub = PrimeHub()

# Initialize StopWatch
stop_watch = StopWatch()


# Straight (PID) funtion
def straightPID(velocity, target, direction):    
    
    #Advances forwards or backwards until it reaches the target at the given velocity
    #- velocity: Velocity of the motors. this velocity will be changed by a little by the pid to correct the path and direction of the robot
    #- target: Target value of the drive motors encoders mean. 
    #- direction: Direction at which the gyro should be. The difference between the real value in each iteration and the direction will be the error of the PID
    

    # Kp, Ki and Kd factors to apply. constants
    kp = 0.02
    ki = 0
    kd = 0

    integral = 0

    # Multiply the velocity by 10 to approximatly convert from velocity percentage (-100, 100) to degrees per second.
    velocity *= 10

    #last time the loop ran
    last_time = stop_watch.time()
    last_error = direction

    # If the robot is going forwards, the < sign should be used, if it is going backwards, > should be used.
    if velocity > 0:
        check_done = lambda : (m_left.angle() + -m_right.angle()) / 2 < target
    else:
        check_done = lambda : (m_left.angle() + -m_right.angle()) / 2 > target

    "main loop"
    # The loop will run while the mean of the motor encoders is lower than the target.
    # Due to the motors being turned 180º in the core, the encoder of the right motor has to be negative. (This may change)
    while check_done():

        delta_time = stop_watch.time() - last_time
        last_time = stop_watch.time()

        if delta_time < 0.001: delta_time = 0.001

        wait(100)

        # Get the current error.
        error = hub.imu.heading() - direction

        integral += error * delta_time

        # Multiply the error times the kp factor to get the proportional correction.
        p_correction = error * kp
        i_correction = integral * ki
        d_correction = (error - last_error)/(delta_time) * kd

        last_error = error        

        k = p_correction + i_correction + d_correction

        # Gets the final motor velocities for this iteration applying the correction to the given velocity.
        # If the robot is going backwards, the correction is the opposite of going forward.
        if velocity > 0:
            v_left = (1 - k) * velocity
            v_right = (1 + k) * velocity
        else:
            v_left = (1 + k) * velocity
            v_right = (1 - k) * velocity
        
        # Print values.
        #print(f"error {error:<20} heading {hub.imu.heading():<20} p {p_correction:<10} i {i_correction:<10} d {d_correction:<10} k {k:<10} v_left {v_left:<20} v_left {v_right:<20}")
        
        # Due to the motors being turned 180º in the core, the velocity given to the motors has to be opposite to go straight. (This may change)
        m_left.run(v_left)
        m_right.run(-v_right)

    # Stop and hold motors at current position after target encoder value reached
    m_left.hold()
    m_right.hold() 
    

# Turn function
def turn(left_speed, right_speed, target_angle):
    m_left.control.limits(1000, 500, 200)  #configures max speed, accel, torque
    m_right.control.limits(1000, 500, 200)

    # Right turn
    if hub.imu.heading() < target_angle:
        left_velocity = left_speed
        right_velocity = right_speed
        m_left.run(left_velocity)
        m_right.run(right_velocity)

        while hub.imu.heading() < (target_angle - 20):
            pass
        if right_velocity == 0:
            m_left.run(40*left_velocity/abs(left_velocity))
            m_right.run(0)
        elif left_velocity == 0:
            m_left.run(0)
            m_right.run(40*right_velocity/abs(right_velocity))
        else:
            m_left.run(40*left_velocity/abs(left_velocity))
            m_right.run(40*right_velocity/abs(right_velocity))
        while hub.imu.heading() < target_angle:
            pass
    
    # Left turn
    if hub.imu.heading() > target_angle:
        left_velocity = -left_speed
        right_velocity = -right_speed
        m_left.run(left_velocity)
        m_right.run(right_velocity)

        while hub.imu.heading() > (target_angle + 20):
            pass
        if right_velocity == 0:
            m_left.run(40*left_velocity/abs(left_velocity))
            m_right.run(0)
        elif left_velocity == 0:
            m_left.run(0)
            m_right.run(40*right_velocity/abs(right_velocity))
        else:
            m_left.run(40*left_velocity/abs(left_velocity))
            m_right.run(40*right_velocity/abs(right_velocity))
        while hub.imu.heading() > target_angle:
            pass

    # Stop and hold motors at current position
    m_left.hold()
    m_right.hold()

    # Reset both wheel motor encoders
    m_left.reset_angle(0)
    m_right.reset_angle(0)


# Initialize button variables
pressed = []
run_number = 1
hub.display.char(str(run_number))
last_buttons = ()



" Example Code "
# straightPID(velocity = 30, target = 500, direction = 0)
    # velocity: velocity of the wheel motors
    # target: average wheel motor encoder value you want to move to 
    # direction: the heading angle at which the robot should be driving along
# turn(left_speed = 150, right_speed = 150, target_angle = 45)
    # left_speed: left wheel motor speed 
    # right speed: right wheel motor speed
    # target_angle: angle heading you want to turn to
# FB_Attachment(speed = 200, angle = 180, pause = True)
    # speed: attachment motor speed
    # angle: how many degrees you want the attachment motor to rotate
    # pause: True or False on whether to wait until attachment motion completes before moving to next line
# LR_Attachment(speed = 100, angle = -75, pause = False)
    # speed: attachment motor speed
    # angle: how many degrees you want the attachment motor to rotate
    # pause: True or False on whether to wait until attachment motion completes before moving to next line



" Run Code "
def run1(): 
    #Reset gyro angle
    hub.imu.reset_heading(0)
    print(hub.imu.heading())
     
    # Reset both wheel motor encoders
    m_left.reset_angle(0)
    m_right.reset_angle(0)
    


    
def run2(): 
    #Reset gyro angle
    hub.imu.reset_heading(0)
    print(hub.imu.heading())
     
    # Reset both wheel motor encoders
    m_left.reset_angle(0)
    m_right.reset_angle(0)




def run3(): 
    #Reset gyro angle
    hub.imu.reset_heading(0)
    print(hub.imu.heading())
     
    # Reset both wheel motor encoders
    m_left.reset_angle(0)
    m_right.reset_angle(0)




def run4(): 
    #Reset gyro angle
    hub.imu.reset_heading(0)
    print(hub.imu.heading())
     
    # Reset both wheel motor encoders
    m_left.reset_angle(0)
    m_right.reset_angle(0)




def run5(): 
    #Reset gyro angle
    hub.imu.reset_heading(0)
    print(hub.imu.heading())
     
    # Reset both wheel motor encoders
    m_left.reset_angle(0)
    m_right.reset_angle(0)
    



def run6(): 
    #Reset gyro angle
    hub.imu.reset_heading(0)
    print(hub.imu.heading())
     
    # Reset both wheel motor encoders
    m_left.reset_angle(0)
    m_right.reset_angle(0)
    




""" Permanent loop to process any button that is pressed """
while True:
    buttons = hub.buttons.pressed()
    released_buttons = set(last_buttons) - set(buttons)

    """ Process the button that was pressed """
    if (Button.LEFT in released_buttons):
        run_number = run_number + 1
        if run_number > 9:
            run_number = 1
        hub.display.char(str(run_number))
    
    if (Button.RIGHT in released_buttons):
        if run_number == 1:
                run1()
                run_number = run_number + 1
                hub.display.char(str(run_number))
        elif run_number == 2:
                run2()
                run_number = run_number + 1
                hub.display.char(str(run_number))
        elif run_number == 3:
                run3()
                run_number = run_number + 1
                hub.display.char(str(run_number))
        elif run_number == 4:
                run4()
                run_number = run_number + 1
                hub.display.char(str(run_number))
        elif run_number == 5:
                run5()
                run_number = run_number + 1
                hub.display.char(str(run_number))
        elif run_number == 6:
                run6()
                run_number = 1
                hub.display.char(str(run_number))

    last_buttons = buttons